/*
 * @Author: smallStone 
 * @Date: 2017-07-24 18:34:25 
 * @Last Modified by: smallStone
 * @Last Modified time: 2018-05-04 16:40:09
 */
var utils = {
	version:0.93,
	
	escapedFileName: function(string){
		var notAllowedChars = [NSCharacterSet characterSetWithCharactersInString:@"\\<>=,!#$&'()*+/:;=?@[]%"];
		var cleanString = [[string componentsSeparatedByCharactersInSet:notAllowedChars] componentsJoinedByString:@""];
		return cleanString;
	},

	getUserDefaultsValue: function(context, key){
		var value = NSUserDefaults.standardUserDefaults().objectForKey(key);
		if (value) {
			return value;
		} else {
			return false;
		}
	},

	setUserDefaultsValue: function(context, key, val){
		[[NSUserDefaults standardUserDefaults] setObject:val forKey:key];
		[[NSUserDefaults standardUserDefaults] synchronize];
		this.sketchLog("setUserDefaultsValue(): key:" + key + ", value:" + val);
	},

	removeUserDefaultsValue: function(context, key) {
		NSUserDefaults.standardUserDefaults().removeObjectForKey(key);
		this.sketchLog("removeUserDefaultsValue(): key:" + key);
	},

	sketchLog: function(string){
		NSLog("lanhuLog::" + string)
	},

	alert: function(context, text, title ){
		var alert = NSAlert.alloc().init();
		var plugin = context.plugin;
		var imageFilePath=[plugin urlForResourceNamed:"logo.png"];
		var imageData = [NSData dataWithContentsOfURL:imageFilePath];
		var image = NSImage.alloc().initWithData(imageData);
		alert.setIcon(image);
		alert.setInformativeText(text);
		if(title){
			alert.setMessageText(title);
		}else{
			alert.setMessageText('似乎出了点小问题~');
		};
		alert.addButtonWithTitle("我知道了");
		alert.runModal();
		this.sketchLog(context,"alert(): title:" + title + ", text:" + text);
	},

	renderWebView: function(context,isAll,count,callback){
		var result = false,
			width = 540,
			height = 430,
			_this = this,
			bgcolor = NSColor.colorWithRed_green_blue_alpha(1, 1, 1, 1);
		if(rootUrl=="https://dev.lanhuapp.com/"){
			url = rootUrl + '/sketch' + '?time='+Math.random()*100;
		}else{
			url = rootUrl + '/sketch_test' + '?time='+Math.random()*100;
		}
		log('renderWebView')
		COScript.currentCOScript().setShouldKeepAround_(true);

		var webViewPanel = NSPanel.alloc().init();
		webViewPanel.setTitleVisibility(NSWindowTitleHidden);
		webViewPanel.setTitlebarAppearsTransparent(true);
        webViewPanel.standardWindowButton(NSWindowCloseButton).setHidden(false);
        webViewPanel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
        webViewPanel.standardWindowButton(NSWindowZoomButton).setHidden(true);
        webViewPanel.setFrame_display(NSMakeRect(0, 0, width, height ), false);
        webViewPanel.setBackgroundColor(bgcolor);

        var contentView = webViewPanel.contentView(),
            webView = WebView.alloc().initWithFrame(NSMakeRect(0, 0, width, height)),
            windowObject = webView.windowScriptObject(),
            delegate = new MochaJSDelegate();
			
		delegate.setHandlerForSelector("webView:didFinishLoadForFrame:", function(webView, webFrame){
			windowObject.evaluateWebScript("vm.artboards="+count.artboards);
			windowObject.evaluateWebScript("vm.allArtboards="+count.allArtboards);
			windowObject.evaluateWebScript("vm.allSlice="+count.allSlice);
			//是否引导过
			var guide = _this.getUserDefaultsValue(context, 'guide');
			if(!guide){
				windowObject.evaluateWebScript("vm.showGuide=true");
				windowObject.evaluateWebScript("vm.showSizeGuide=true");
			}
			
			var lanhuToken = _this.getUserDefaultsValue(context, 'lanhuToken');
			var select = _this.getUserDefaultsValue(context, 'select');
			if(lanhuToken && select){
				windowObject.evaluateWebScript("vm.status.isLogin=true");
				//进入上传页面
				if(select){
					var data = {
						token: new String(lanhuToken).toString(),
						select: new String(select).toString()
					};
					// windowObject.evaluateWebScript("vm.scale=" + scale)
					windowObject.evaluateWebScript("vm.goUpload(" + JSON.stringify(data) + ")");
				};

				// var ArtboardScale = _this.getUserDefaultsValue(context, 'ArtboardScale');
				// if(ArtboardScale){
				// 	windowObject.evaluateWebScript("vm.ArtboardScale=" + ArtboardScale);
				// };
				try{
				var sizeText = _this.getUserDefaultsValue(context, 'sizeText'),
					sliceScale = _this.getUserDefaultsValue(context, 'sliceScale');
				if(sizeText){
					var sizeData = {
						sizeText:new String(sizeText).toString(),
						sliceScale: new String(sliceScale).toString()
					}
					windowObject.evaluateWebScript("vm.setSize(" + JSON.stringify(sizeData) + ")");
				}}catch(e){return true}
				
				//选择全部还是选中的Artboard
				if(isAll){
					windowObject.evaluateWebScript("vm.uploadType='all'");
				}else{
					windowObject.evaluateWebScript("vm.uploadType='selected'");
				}
			}else{
				//第一次登录
				windowObject.evaluateWebScript("vm.status.isLogin=false");
			};

			//获取文件路径
			try {
				var filePath = context.document.fileURL().path()
				var filedata = {
					path:new String(filePath).toString()
				}
				windowObject.evaluateWebScript("vm.setFilePath(" + JSON.stringify(filedata) + ")");
				log('filePath'+filePath)
			} catch (error) {
				log('filePath'+error)
			}
			
			//windowObject.evaluateWebScript("webViewInit(" + JSON.stringify(settings) + ")");
			windowObject.evaluateWebScript("vm.getNewVersion('" + _this.version + "')");
			COScript.currentCOScript().setShouldKeepAround_(false);
		});
		
		delegate.setHandlerForSelector("webView:didChangeLocationWithinPageForFrame:", function(webView, webFrame){
			var webViewRequest = NSURL.URLWithString(webView.mainFrameURL()).fragment();

			if(webViewRequest == "close") {
				COScript.currentCOScript().setShouldKeepAround_(false)
				webViewPanel.orderOut(nil);
				NSApp.stopModal();
			} else {
				//get result data and execute callback
				var webViewData = JSON.parse(decodeURI(windowObject.valueForKey("webViewData")));
				callback(webViewPanel, NSApp, webViewRequest, webViewData, windowObject);
				result = true;
			}
			COScript.currentCOScript().setShouldKeepAround_(false);
		});

        contentView.setWantsLayer(true);
        contentView.layer().setFrame( contentView.frame() );
        contentView.layer().setCornerRadius(6);
        contentView.layer().setMasksToBounds(true);

        webView.setBackgroundColor(bgcolor);
        webView.setFrameLoadDelegate_(delegate.getClassInstance());
        webView.setMainFrameURL_(url);

		contentView.addSubview(webView);

        var closeButton = webViewPanel.standardWindowButton(NSWindowCloseButton);
        closeButton.setCOSJSTargetFunction(function(sender) {
			self.wantsStop = true;
            webViewPanel.orderOut(nil);
            NSApp.stopModal();
        });
        closeButton.setAction("callAction:");
		NSApp.runModalForWindow(webViewPanel);
        return result;
    }
}