/*
 * @Author: smallStone 
 * @Date: 2017-07-24 18:34:25 
 * @Last Modified by: smallStone
 * @Last Modified time: 2018-05-04 16:39:56
 */
@import 'tools/MochaJSDelegate.js';
@import 'tools/tool.js';
@import 'tools/getLayer.js';

var uploadAllArtboardLanhu = function(context){
	onRun(context,true);
};

var uploadSelectArtboardLanhu = function(context){
	onRun(context,false)
};
var projectId = '',
	selectedObj = {},
	rootUrl = "https://lanhuapp.com/";

var saveDocument = function(context){
	//检查文件是否保存
	try{
		var res,
		document = context.document,
			path = document.fileURL().path(),
			name = NSUserName();
		if(!path){
			//文件从未保存
			utils.alert(context,"请先保存文件再上传哦！","文件未保存")
			res =  false
		}else if(document.isDocumentEdited()){
			//文件编辑后未保存
			var alert = NSAlert.alloc().init();
			var plugin = context.plugin;
			var imageFilePath=[plugin urlForResourceNamed:"logo.png"];
			var imageData = [NSData dataWithContentsOfURL:imageFilePath];
			var image = NSImage.alloc().initWithData(imageData);
			alert.setIcon(image);
			alert.setInformativeText('请保存文件后再上传');
			alert.setMessageText('文件未保存');
			alert.addButtonWithTitle("保存并继续");
			alert.addButtonWithTitle("我知道了");
			var code = alert.runModal();
			if(code=='1000'){
				log('save')
				document.saveDocument(nil);
				res = true
			}else{
				res = false
			}
		}else {
			res =  true
		}
		
		return res
	}catch(e){
		//读取失败统一按照没有保存来
		utils.alert(context,"请先保存文件再上传哦！","文件未保存")
		return false
	}
}

var onRun = function (context,isAll) {
	var issaved = saveDocument(context)
	if(!issaved){
		return false
	}
	//检查sketch版本
	log('proId:'+0000)
	var isTipVersion = utils.getUserDefaultsValue(context,'noversion')
	if(!isTipVersion){
		checkSketchVersion(context)
	}
    //获取token
	// var lanhuToken = utils.getUserDefaultsValue(context, 'lanhuToken');
	var proId = utils.getUserDefaultsValue(context, 'proId');
	projectId = proId
	// if(lanhuToken && proId){
	// 	projectId = proId;
	// };
	//获取选择的Artboard
	getSelected(context);
	//获取画板的数量和切图数量
	try {
	var allArtboards = context.document.currentPage().artboards().count() || 0,
		allSlice = context.document.currentPage().exportableLayers().count() || 0;
	
	} catch (error) {
		var allArtboards = 0,	allSlice=0;
	}
	var count = {
		allSlice:allSlice,
		allArtboards:allArtboards,
		artboards:Object.keys(selectedObj).length
	};
    utils.renderWebView(context,isAll,count,function(webViewPanel, NSApp, webViewRequest, webViewData, windowObject) {
		var document = context.document,ArtboardScale;
		//execute action received from webview
		if (webViewRequest == "login") {
            // utils.alert(context,webViewData)
            var lanhuToken = webViewData.token;
            utils.setUserDefaultsValue(context,'lanhuToken',lanhuToken);
            utils.sketchLog('登录成功！' );
		};

		// if (webViewRequest == "ArtboardScale") {
		// 	ArtboardScale = webViewData.ArtboardScale;
		// 	utils.setUserDefaultsValue(context,'ArtboardScale',ArtboardScale);
		// 	utils.sketchLog('选择上传倍数' )
		// };

		// if (webViewRequest == "changeType") {
        //     // utils.alert(context,webViewData)
        //     var type = webViewData.type;
        //     utils.setUserDefaultsValue(context,'type',type);
        //     utils.sketchLog('type:' +  type)
		// };

        if (webViewRequest == "selected") {
			var select = JSON.stringify(webViewData);
			var proId = webViewData.selected.proId;
			projectId = proId;
			utils.setUserDefaultsValue(context,'select',select);
			utils.setUserDefaultsValue(context,'proId',proId);
            utils.sketchLog('选择团队和项目' );
		};
		
		if (webViewRequest == "hideguide") {
			utils.setUserDefaultsValue(context,'guide',true);
        };
		
		if (webViewRequest == "logout") {
			utils.sketchLog("click logout");
			utils.removeUserDefaultsValue(context, "lanhuToken");
			utils.removeUserDefaultsValue(context, "select");
		};

		if (webViewRequest == "all" || (webViewRequest == "pages" && Object.keys(selectedObj).length>0)) {
			// COScript.currentCOScript().setShouldKeepAround_(true);
			
			if(document.currentPage().artboards().length==0){
				utils.alert(context,'当前pages似乎没有artboard');
				utils.sketchLog('当前pages似乎没有artboard');
				return false;
			};
			
			var loop = document.currentPage().artboards().objectEnumerator(),
				result = 0,
				allData = [],
				sliceScale = webViewData.sliceScale,
				ArtboardScale = webViewData.ArtboardScale,
				sizeText = webViewData.sizeText;
			utils.setUserDefaultsValue(context,'sizeText',sizeText);
			utils.setUserDefaultsValue(context,'sliceScale',sliceScale);
 			for(var i = 0 ; i < document.currentPage().artboards().length; i++){
				if(document.currentPage().artboards()[i].class()=='MSArtboardGroup'){
					if(webViewRequest == "pages"){
						//导出选中
						for(var j in selectedObj){
							if(j==document.currentPage().artboards()[i].objectID()){
								result++;
							}
						}
					}else{
						//导出全部
						result++
					}
				}
			};
			if(result==0){
				utils.alert(context,'当前pages似乎没有artboard');
				utils.sketchLog('当前pages似乎没有artboard');
				return false;
			};
			var res = {
				result:new String(result).toString()
			};
			windowObject.evaluateWebScript("vm.getAllProcess(" + JSON.stringify(res) + ")");

			getLayerObj = new getLayer();
			getLayerObj.init(context, document,sliceScale,ArtboardScale);
			
			while(msArtboard = loop.nextObject()){
				if(msArtboard.class()=='MSArtboardGroup'){
					if(webViewRequest == "pages"){
						//导出选中
						for(var j in selectedObj){
							if(j==msArtboard.objectID()){
								windowObject.evaluateWebScript("vm.process()");
								var info = getLayerObj.getArtboard(msArtboard);
								allData.push(info)
							}
						}
					}else{
						//导出全部
						windowObject.evaluateWebScript("vm.process()");
						var info = getLayerObj.getArtboard(msArtboard);
						allData.push(info)
					}
				}
			};
			
			for(var i = 0; i < allData.length; i++){
				windowObject.evaluateWebScript("vm.uploadJSON(" + JSON.stringify(allData[i].data) + ", '" +allData[i].base64 + "')");
			}
			windowObject.evaluateWebScript("vm.cocoaDone='true'");
			utils.sketchLog('循环完了~！！');
		};

		if (webViewRequest == "register") {
			utils.sketchLog("click register");
			var webUrl = rootUrl + 'web/#!/user/register';
			var url = [NSURL URLWithString:webUrl];
			[[NSWorkspace sharedWorkspace] openURL:url];
		};

		if (webViewRequest == "web1") {
			utils.sketchLog("click web1");
			var webUrl = rootUrl + 'web';
			var url = [NSURL URLWithString:webUrl];
			[[NSWorkspace sharedWorkspace] openURL:url];
		};
		

		if (webViewRequest == "web") {
			utils.sketchLog("click web");
			var webUrl = rootUrl + 'web/#!/item/board?pid=' + projectId;
			var url = [NSURL URLWithString:webUrl];
			[[NSWorkspace sharedWorkspace] openURL:url];
		};
		
		if (webViewRequest == "help") {
			utils.sketchLog("openLogin: click help");
			var url = [NSURL URLWithString:@"http://help.lanhuapp.com/hc/kb/article/1068673"];
			[[NSWorkspace sharedWorkspace] openURL:url];
		};

		if (webViewRequest == "url" || webViewRequest == "update" || webViewRequest == "helpicon") { 
			var webUrl = webViewData.url;
			var url = [NSURL URLWithString:webUrl];
			[[NSWorkspace sharedWorkspace] openURL:url];
		};
		

		if(webViewRequest == 'newversion'){
			//新版本
			var cancelalert = NSAlert.alloc().init();
			var cancelplugin = context.plugin;
			var cancelimageFilePath=[cancelplugin urlForResourceNamed:"logo.png"];
			var cancelimageData = [NSData dataWithContentsOfURL:cancelimageFilePath];
			var cancelimage = NSImage.alloc().initWithData(cancelimageData);
			cancelalert.setIcon(cancelimage);
			cancelalert.setMessageText('哇~发现超腻害的新版本，要不要现在体验下？');
			cancelalert.addButtonWithTitle("带朕看看");
			cancelalert.addButtonWithTitle("朕就不要");
			var code = cancelalert.runModal();
			utils.sketchLog(code);
			if(code == 1000){
				var url = [NSURL URLWithString:webViewData.url];
				[[NSWorkspace sharedWorkspace] openURL:url];
			};
		};

		if (webViewRequest == "report") {
			utils.sketchLog("openReportIssue: click report");
			utils.sketchLog(webViewData);
			// //read log and send
			// var root = "/private/var/log/system.log";
			// var sysLogs = [NSString stringWithContentsOfFile:root encoding:NSUTF8StringEncoding error:nil]

			// // first, separate by new line
			// var logs = [sysLogs componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]],
			// filteredLogs = [];

			// //filter cf logs
			// for (var i = 0; i <= 100; i++) {
			// 	filteredLogs.push(logs[i]);
			// }

			// filteredLogs = filteredLogs.join("\n");
			if(webViewData.length>0){
				var errstr = webViewData.join("\n");
				[[NSPasteboard generalPasteboard] declareTypes:[NSArray arrayWithObject:NSStringPboardType] owner:self];
				[[NSPasteboard generalPasteboard] setString:errstr forType:NSStringPboardType];
				utils.alert(context,'cmd+v即可粘贴','复制成功');
			}else{
				utils.alert(context,'好像没有错误日志哦~','');
			}
		}
    });
};



var getSelected = function (context){
    //获取用户选择的
	var seletctCount = 0;
    for (var i = 0; i < context.selection.count(); i++) {
		try {
        seletctCount++;
        var artid = context.selection[i].parentArtboard().objectID();
		selectedObj[artid] = true;
		} catch (error) {
		}
    }
};

var checkSketchVersion = function(context){
	var sketch = context.api(),
		text = '发现你的sketch版本过低，如继续使用可能会造成数据解析错误，建议升级到最新版本',
		title = '当前版本过低';
	if(sketch.version<46){
		var alert = NSAlert.alloc().init();
		var plugin = context.plugin;
		var imageFilePath=[plugin urlForResourceNamed:"logo.png"];
		var imageData = [NSData dataWithContentsOfURL:imageFilePath];
		var image = NSImage.alloc().initWithData(imageData);
		alert.setIcon(image);
		alert.setInformativeText(text);
		alert.setMessageText(title);
		alert.addButtonWithTitle("我知道了");
		alert.addButtonWithTitle("不再提醒");
		var code = alert.runModal();
		if(code==1001){
			//不再提醒
			utils.setUserDefaultsValue(context,'noversion',true)
		}
	}
}